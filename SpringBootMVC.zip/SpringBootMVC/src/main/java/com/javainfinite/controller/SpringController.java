package com.javainfinite.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.javainfinite.model.Employee;

@Controller
public class SpringController {
	
	@Autowired
	Employee employee;

	@RequestMapping(value = "/")
	public String welcome(Model model) {
		model.addAttribute("Employee", employee);
		return "home";
	}
	
	@RequestMapping(value="/welcome", method=RequestMethod.POST)
	public String welcomeUser(@RequestParam("empName") String name, Model model) {
		model.addAttribute("name", name);
		return "welcome";
	}
}
